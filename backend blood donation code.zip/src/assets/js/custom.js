$(document).ready(function () {
    $('.sidebar-menu').tree()
  })