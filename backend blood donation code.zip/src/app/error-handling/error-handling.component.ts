import { Component, OnInit } from "@angular/core";
import { ActivatedRoute } from "@angular/router";
import { Location } from "@angular/common";
@Component({
  selector: 'app-error-handling',
  templateUrl: './error-handling.component.html',
  styleUrls: ['./error-handling.component.css']
})
export class ErrorHandlingComponent implements OnInit {
  code: any;
  constructor(private route: ActivatedRoute, private location: Location) {}

  ngOnInit() {
    this.code = this.route.snapshot.paramMap.get("code");
  }

  backtopage() {
    this.location.back();
  }

}
