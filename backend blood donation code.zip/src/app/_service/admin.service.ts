import { Injectable } from '@angular/core';
import { observable } from "rxjs";
import { map } from "rxjs/operators";
import { HttpClient,HttpHeaders } from "@angular/common/http";
import { environment } from "../../environments/environment";

@Injectable({
  providedIn: 'root'
})
export class AdminService {

  public base_url: any;
  constructor(public http:HttpClient) { 
    this.base_url = environment.base_url;
  }

  checkLogin(data) {
   console.log(this.base_url)
    return this.http
      .post<any>(this.base_url + "Admin/checkLogin",data)
      .pipe(
        map(res => {
          return res;
        })
      );
  }

  getUsers()
  {
    return this.http.get<any>(this.base_url + 'Admin/getUsers');
  }

  getDashboardInfo()
  {
    return this.http.get<any>(this.base_url + 'Admin/getDashboardInfo');
  }
  getAllRequest(status)
  {
    return this.http.post<any>(this.base_url + 'Admin/getAllRequest',status);
  }

  UserSearch(status)
  {
    return this.http.post<any>(this.base_url + 'Admin/UserSearch',status);
  }

  RequestSearch(status)
  {
    return this.http.post<any>(this.base_url + 'Admin/RequestSearch',status);
  }

  CompletedSearch(status)
  {
    return this.http.post<any>(this.base_url + 'Admin/CompletedSearch',status);
  }

  getFeedback()
  {
    return this.http.get<any>(this.base_url + 'Admin/getFeedback');
  }

  feedbackSearch(data)
  {
    return this.http.post<any>(this.base_url + 'Admin/feedbackSearch',data);
  }
  
}
