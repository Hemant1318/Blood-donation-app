import { Component, OnInit } from '@angular/core';
import { AdminService } from '../_service/admin.service'
@Component({
  selector: 'app-completed',
  templateUrl: './completed.component.html',
  styleUrls: ['./completed.component.css']
})
export class CompletedComponent implements OnInit {
  p: number = 1;
  collection: any[]; 
  pinfo:any;
  from:string;
  to:string;
  searchstring:string;
  status='completed';
  constructor(public api: AdminService) { }
  ngOnInit() {
    this.getRequest();
  }

  getRequest()
  {
    this.api.getAllRequest({'status':this.status}).subscribe(res => {
      console.log(res)
      this.collection=res
      
      })
  }

  
  search()
  {
    this.api.CompletedSearch({'from':this.from,'to':this.to,'status':this.status}).subscribe(res => {
      console.log(res)
      this.collection=res
      
      })
  }
}
