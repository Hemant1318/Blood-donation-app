import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule,HTTP_INTERCEPTORS } from '@angular/common/http';
import { ToastrModule } from 'ng6-toastr-notifications';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {NgxPaginationModule} from 'ngx-pagination';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { InterceptorService } from './_helper/interceptor.service';
import { ErrorHandlingComponent } from './error-handling/error-handling.component';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './template/header/header.component';
import { SidebarComponent } from './template/sidebar/sidebar.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { UsersListComponent } from './users-list/users-list.component';
import { LoginComponent } from './login/login.component';
import { RequestComponent } from './request/request.component';
import { CompletedComponent } from './completed/completed.component';
import { ErrorHandlerService } from './_helper/error-handler.service';
import { FeedbackComponent } from './feedback/feedback.component';


@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    SidebarComponent,
    DashboardComponent,
    UsersListComponent,
    LoginComponent,
    RequestComponent,
    CompletedComponent,
    ErrorHandlingComponent,
    FeedbackComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    ToastrModule,
    BrowserAnimationsModule, ToastrModule.forRoot(),NgxPaginationModule
  ],
  providers: [{ provide: HTTP_INTERCEPTORS, useClass: InterceptorService, multi: true },{
    provide: HTTP_INTERCEPTORS,
    useClass: ErrorHandlerService,
    multi: true}],
  bootstrap: [AppComponent]
})
export class AppModule { }
