import { Component, OnInit } from '@angular/core';
import { AdminService } from '../_service/admin.service'
@Component({
  selector: 'app-users-list',
  templateUrl: './users-list.component.html',
  styleUrls: ['./users-list.component.css']
})
export class UsersListComponent implements OnInit {
  p: number = 1;
  collection: any[]; 
  pinfo:any;
  searchstring:string;
  from:string;
  to:string;
  constructor(public api: AdminService) { }
  ngOnInit() {
    this.getUsers();
  }

  getUsers()
  {
    this.api.getUsers().subscribe(res => {
      console.log(res)
      this.collection=res
      
      })
  }

  search()
  {
    this.api.UserSearch({'from':this.from,'to':this.to}).subscribe(res => {
      console.log(res)
      this.collection=res
      
      })
  }
}
