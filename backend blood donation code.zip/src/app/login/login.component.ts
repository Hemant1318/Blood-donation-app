import { Component, OnInit } from '@angular/core';
import { Router } from "@angular/router";
import { ToastrManager } from 'ng6-toastr-notifications';
import { AdminService } from '../_service/admin.service'
import {
  FormBuilder,
  FormGroup,
  FormControl,
  Validators
} from "@angular/forms";

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loginForm: FormGroup;
  submitted = false;
  constructor(public api:AdminService, public toastr: ToastrManager,private fb: FormBuilder,private router: Router) { }

  ngOnInit() {
    this.loginForm = this.fb.group({
      username: ["", Validators.required],
      password: ["", Validators.required]
    });
     let token=sessionStorage.getItem('userToken');
     if(token!=null)
    {
      this.router.navigate(['dashboard']);
    }  
  }

  get f() {
    return this.loginForm.controls;
  }

  login() {
    console.log(this.loginForm.value.username);
    this.submitted = true;

    // stop here if form is invalid
    if (this.loginForm.invalid) {
      return;
    }

     this.api.checkLogin(this.loginForm.value).subscribe(res => {
      console.log(res);
      if (res!= 0) {
       this.toastr.successToastr("Login Sucsssfull");
       sessionStorage.setItem("userToken", res.token);
       sessionStorage.setItem("role", res.role);

        this.router.navigate(["/dashboard"]);
      } else {
        this.toastr.errorToastr("Invalid details.");
      }
    }); 
  }



}
