import { Component, OnInit } from '@angular/core';
import { AdminService } from '../_service/admin.service'
@Component({
  selector: 'app-request',
  templateUrl: './request.component.html',
  styleUrls: ['./request.component.css']
})
export class RequestComponent implements OnInit {
  p: number = 1;
  collection: any[]; 
  pinfo:any;
  from:string;
  to:string;
  searchstring:string;
  constructor(public api: AdminService) { }
  ngOnInit() {
    this.getRequest();
  }

  getRequest()
  {
    this.api.getAllRequest({'status':'requested'}).subscribe(res => {
      console.log(res)
      this.collection=res
      
      })
  }

  search()
  {
    this.api.RequestSearch({'from':this.from,'to':this.to}).subscribe(res => {
      console.log(res)
      this.collection=res
      
      })
  }
}
