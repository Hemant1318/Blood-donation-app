import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DashboardComponent } from './dashboard/dashboard.component';
import { LoginComponent } from './login/login.component';
import { UsersListComponent } from './users-list/users-list.component';
import { RequestComponent } from './request/request.component';
import { CompletedComponent } from './completed/completed.component';
import { FeedbackComponent } from './feedback/feedback.component';


const routes: Routes = [
  {path:"dashboard",component:DashboardComponent},
  {path:"login",component:LoginComponent},
  {path:"",component:LoginComponent},
  {path:"users",component:UsersListComponent},
  {path:"request",component:RequestComponent},
  {path:"completed",component:CompletedComponent},
  {path:"feedback",component:FeedbackComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
