import { Component, OnInit } from '@angular/core';
import { AdminService } from '../_service/admin.service';
declare var jquery: any;
declare var $: any;
import { environment } from "../../environments/environment";
@Component({
  selector: 'app-feedback',
  templateUrl: './feedback.component.html',
  styleUrls: ['./feedback.component.css']
})
export class FeedbackComponent implements OnInit {
  p: number = 1;
  collection: any[]; 
  pinfo:any;
  from:string;
  to:string;
  searchstring:string;
  base_url = environment.base_url;
  constructor(public api: AdminService) { }
  ngOnInit() {
    this.getFeedback();
  }

  getFeedback()
  {
    this.api.getFeedback().subscribe(res => {
      console.log(res)
      this.collection=res    
      })
  }

  
  search()
  {
    this.api.feedbackSearch({'from':this.from,'to':this.to}).subscribe(res => {
      console.log(res)
      this.collection=res
      
      })
  }
}