import { Component, OnInit } from '@angular/core';
import { AdminService } from '../_service/admin.service'
import { Router } from "@angular/router";

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
data:any;
  constructor(public api: AdminService,private router: Router) { }
  ngOnInit() {
    this.getDashboardInfo();
	  let token=sessionStorage.getItem('userToken');
     if(token==null)
    {
      this.router.navigate(['login']);
    }  
  }

  getDashboardInfo()
  {
        this.api.getDashboardInfo().subscribe(res => {
          console.log(res) 
          this.data=res;
          })
 }

}


