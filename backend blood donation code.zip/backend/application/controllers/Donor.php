<?php defined('BASEPATH') OR exit('No direct script access allowed');

use Restserver\Libraries\REST_Controller;
if (isset($_SERVER['HTTP_ORIGIN'])) {
		header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
		header('Access-Control-Allow-Credentials: true');
		header('Access-Control-Max-Age: 86400'); 
	  }
		if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
		if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']))
				header("Access-Control-Allow-Methods: GET, POST, OPTIONS");         

			if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']))
				header("Access-Control-Allow-Headers: {$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");
				exit(0);
		}
require APPPATH . '/libraries/REST_Controller.php';
 
class Donor extends \Restserver\Libraries\REST_Controller
{
    public function __construct() {
        parent::__construct();
        // Load User Model
        $this->load->model('Donor_model');
    }
	 
	 /** get all request 
     * --------------------------
     * @method : get
     * @link: api/Donor/getAllRequest
     */
	 
	 public function getAllRequest_get()
	 {
		 $is_valid_token = $this->authorization_token->validateToken();
        if (!empty($is_valid_token) AND $is_valid_token['status'] === TRUE)
        {
			$data=$this->Donor_model->getAllRequestById($is_valid_token['data']->id);
			
			
				 $message = [
                    'status' => true,
                    'data'=> $data
                ];
                $this->response($message, REST_Controller::HTTP_OK);
		}else{		
			$message = [
                    'status' => FALSE,
                    'message' => "token not found"
						];
                $this->response($message, REST_Controller::HTTP_NOT_FOUND);
		}
	 }
	 
	 /** get seeker Info 
     * --------------------------
     * @method : POST
     * @link: api/Donor/getRequest
     */
	 
	 public function getSeekerInfo_post()
	 {
		 $this->load->model('Seeker_model');
		$is_valid_token = $this->authorization_token->validateToken();
        if (!empty($is_valid_token) AND $is_valid_token['status'] === TRUE)
        {
			$this->form_validation->set_rules('seeker_id', 'seeker_id', 'trim|required');
			if ($this->form_validation->run() == TRUE)
			{
			    
				if($output=$this->Seeker_model->getDonarInfo($this->input->post('seeker_id')))
				{			
				   $this->response(array('status' => true,'data'=>$output), REST_Controller::HTTP_OK);
				
				}else{
					  $this->response(array('status' => false,'message'=>'internal server error'), REST_Controller::HTTP_NOT_FOUND);
				}
			}else{
				$message = array(
									'status' => false,
									'error' => $this->form_validation->error_array(),
									'message' => validation_errors()
								);
		    	 $this->response($message, REST_Controller::HTTP_NOT_FOUND);
			}	
		}else{		
			 $message = [
                    'status' => FALSE,
                    'message' => "token not available"
                ];
                $this->response($message, REST_Controller::HTTP_NOT_FOUND);
		}
	 }
	 
	 /** action on request
     * --------------------------
     * @method : POST
     * @link: api/Donor/getRequest
     */
	 
	public function actionOnRequest_post()
	{
		$is_valid_token = $this->authorization_token->validateToken();
        if (!empty($is_valid_token) AND $is_valid_token['status'] === TRUE)
        {
			$this->form_validation->set_rules('blood_request_id', 'blood_request_id', 'trim|required');
			$this->form_validation->set_rules('action', 'action', 'trim|required');
			if ($this->form_validation->run() == TRUE)
			{
			    $data=$this->input->post();
				
				if($output=$this->Donor_model->actionOnRequest($data))
				{			
				   $this->response(array('status' => true,'message'=>'updated successfully'), REST_Controller::HTTP_OK);
				
				}else{
					  $this->response(array('status' => false,'message'=>'internal server error'), REST_Controller::HTTP_NOT_FOUND);
				}
			}else{
				$message = array(
									'status' => false,
									'error' => $this->form_validation->error_array(),
									'message' =>validation_errors()
								);
		    	 $this->response($message, REST_Controller::HTTP_NOT_FOUND);
			}	
		}else{		
			 $message = [
                    'status' => FALSE,
                    'message' => "token not available"
                ];
                $this->response($message, REST_Controller::HTTP_NOT_FOUND);
		}
	}
	
	public function isBloodDonated_post()
	{
		$is_valid_token = $this->authorization_token->validateToken();
        if (!empty($is_valid_token) AND $is_valid_token['status'] === TRUE)
        {
			$row=$this->Donor_model->isBloodDonated($is_valid_token['data']->id);
			if(count($row)>=1)
			{
				$this->response(array('status' => true,'message'=>'show the popup','id'=>$row[0]['id']), REST_Controller::HTTP_OK);
			}else{
				$this->response(array('status' => false,'message'=>'Do not show the popup'), REST_Controller::HTTP_OK);
			}
		}else{
			$message = [
                    'status' => FALSE,
                    'message' => "token not available"
                ];
                $this->response($message, REST_Controller::HTTP_NOT_FOUND);
		}
	}
	
	public function actionOnBloodDonation_post()
	{
		$is_valid_token = $this->authorization_token->validateToken();
		if (!empty($is_valid_token) AND $is_valid_token['status'] === TRUE)
        {
			if($this->Donor_model->actionOnBloodDonation($is_valid_token['data']->id,$_POST['action'],$_POST['id']))
			{
				$this->response(array('status' => true,'message'=>'status updated sucessfully'), REST_Controller::HTTP_OK);
			}else{
				$this->response(array('status' => false,'message'=>'internal server error'), REST_Controller::HTTP_NOT_FOUND);
			}

		}else{
			$this->response(array('status' => false,'message'=>'Do not show the popup'), REST_Controller::HTTP_OK);
		}

	}
	
	
	 
	 
	 
	 

}