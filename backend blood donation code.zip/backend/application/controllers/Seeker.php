<?php defined('BASEPATH') OR exit('No direct script access allowed');

use Restserver\Libraries\REST_Controller;
if (isset($_SERVER['HTTP_ORIGIN'])) {
		header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
		header('Access-Control-Allow-Credentials: true');
		header('Access-Control-Max-Age: 86400'); 
	  }
		if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
		if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']))
				header("Access-Control-Allow-Methods: GET, POST, OPTIONS");         

			if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']))
				header("Access-Control-Allow-Headers: {$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");
				exit(0);
		}
require APPPATH . '/libraries/REST_Controller.php';
 
class Seeker extends \Restserver\Libraries\REST_Controller
{
    public function __construct() {
        parent::__construct();
        // Load User Model
        $this->load->model('Seeker_model');
    }
	
	
	/**
     * User signup with mobile API
     * --------------------
     * @param: phone 
     * --------------------------
     * @method : POST
     * @link: api/Seeker/UserSignup
     */
	 
	 
	  public function availabledonar_post() {

        header("Access-Control-Allow-Origin: *");

        # XSS Filtering (https://www.codeigniter.com/user_guide/libraries/security.html)
        $_POST = $this->security->xss_clean($_POST);

        $this->form_validation->set_rules('lagi', 'lagi', 'trim|required');
        $this->form_validation->set_rules('lati', 'lati', 'trim|required');
         
             $this->form_validation->set_rules('Km', 'Km', 'trim|required');
      //  $token_data = $this->authorization_token->userData();
    //    if ($this->form_validation->run() == FALSE or !isset($token_data->UserId)) {
    if ($this->form_validation->run() == FALSE ) {
            $message = [
                    'status' => FALSE,
                    'message' => "invalid parameter or token not found",
                   // 'id'=>$token_data->UserId
                ];
                $this->response($message, REST_Controller::HTTP_NOT_FOUND);
        } else {
          
            $output = $this->Seeker_model->availabledonar($this->input->post('lagi', TRUE),$this->input->post('lati', TRUE),$this->input->post('Km', TRUE));
            //print_r($output);
            if ($output > 0 AND ! empty($output)) {
                $arr=array();
                foreach($output as $out)
                {
                    $out['distance']=10;
                    $arr[]=$out;
                }
                $message = [
                    'status' => true,
                    'message' => "data available",
                    'data'=> $arr
                ];
                $this->response($message, REST_Controller::HTTP_OK);
            } else {
                // Error
                $message = [
                    'status' => FALSE,
                    'message' => "data not available"
                ];
                $this->response($message, REST_Controller::HTTP_NOT_FOUND);
            }
        }
    }
	 
	 
	 
	 
	 public function UserSignup_post()
	 {
        $_POST = $this->security->xss_clean($_POST);
        $this->form_validation->set_rules('phone', 'Mobile', 'trim|required|max_length[10]|min_length[10]', array('is_unique' => 'This %s already exists please enter another mobile no')
        );
        
       $output=$this->Seeker_model->checkUserExististance($_POST['phone']);
        if(!empty($output) && $output[0]['status']!=1)
        {
            $token_data['id'] = $output[0]['user_id'];
                $token_data['username'] =  $output[0]['phone'];
                $token_data['time'] = time();
                $token_data['role'] = $output[0]['role'];

                $user_token = $this->authorization_token->generateToken($token_data);
            $message = array('status' => true, 'message' => 'user already exist','user_status'=>$output[0]['status'],'token'=>$user_token,'role'=>$output[0]['role'],'profile'=>$output[0]['profile'],'name'=>$output[0]['name'],'gender'=>$output[0]['gender'],'dob'=>$output[0]['dob'],'latitude'=>$output[0]['latitude'],'longitude'=>$output[0]['longitude'],'blood_group'=>$output[0]['blood_group'],);
		    echo json_encode($message);
        }else if((!empty($output) && $output[0]['status']==1)){
                
                
        $characters = '123456789' . '789456123';
        $randomString = substr(str_shuffle($characters), rand(0, 13), 4);
        $userOtp = $randomString;
			if ($this->form_validation->run() == True) 
			{
						$authKey = "292001ARN2KOC8W2uf5d6a2a46";
				$mobileNumber = "91" . $this->input->post('phone', TRUE);
				$senderId = "AppoCK";
				//////Sender ID,While using route4 sender id should be 6 characters long.
				$bookingMsg = "Dear User, your recent otp is:" . $userOtp;
				$message = urlencode($bookingMsg);

				//Define route
				$route = "4";
				//Prepare you post parameters
				$postData = array(
					'authkey' => $authKey,
					'mobiles' => $mobileNumber,
					'message' => $message,
					'sender' => $senderId,
					'route' => $route,
					'country' => "91"
				);
				//API URL
				$url = "https://control.msg91.com/sendhttp.php";

				// init the resource
				$ch = curl_init();
				curl_setopt_array($ch, array(
					CURLOPT_URL => $url,
					CURLOPT_RETURNTRANSFER => true,
					CURLOPT_POST => true,
					CURLOPT_POSTFIELDS => $postData
				));

				curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
				curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
				$output = curl_exec($ch);

				if(curl_errno($ch))
				{
					echo 'error:' . curl_error($ch);
				}

					curl_close($ch);
					$this->Seeker_model->updateOtp($userOtp,$_POST['phone']);
					 $message = array('status' => true, 'message' => 'otp sent','user_status'=>1);
		}			   echo json_encode($message);
                
        }else{
        
        $characters = '123456789' . '789456123';
        $randomString = substr(str_shuffle($characters), rand(0, 13), 4);
        $userOtp = $randomString;
			if ($this->form_validation->run() == True) 
			{
						$authKey = "292001ARN2KOC8W2uf5d6a2a46";
				$mobileNumber = "91" . $this->input->post('phone', TRUE);
				$senderId = "AppoCK";
				//////Sender ID,While using route4 sender id should be 6 characters long.
				$bookingMsg = "Dear User, your recent otp is:" . $userOtp;
				$message = urlencode($bookingMsg);

				//Define route
				$route = "4";
				//Prepare you post parameters
				$postData = array(
					'authkey' => $authKey,
					'mobiles' => $mobileNumber,
					'message' => $message,
					'sender' => $senderId,
					'route' => $route,
					'country' => "91"
				);
				//API URL
				$url = "https://control.msg91.com/sendhttp.php";

				// init the resource
				$ch = curl_init();
				curl_setopt_array($ch, array(
					CURLOPT_URL => $url,
					CURLOPT_RETURNTRANSFER => true,
					CURLOPT_POST => true,
					CURLOPT_POSTFIELDS => $postData
				));

				curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
				curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
				$output = curl_exec($ch);

				if(curl_errno($ch))
				{
					echo 'error:' . curl_error($ch);
				}

					curl_close($ch);
					$user=array('phone'=>$this->input->post('phone'),'otp'=>$userOtp,'creation_date'=>Date('Y-m-d'));
				   if($this->Seeker_model->addUser($user))
				   {
					   $message = array('status' => true, 'message' => 'otp sent','user_status'=>1);
					   echo json_encode($message);
				   }			   
			}else{
				$message = array(
                'status' => false,
                'error' => $this->form_validation->error_array(),
                'message' => validation_errors()
            );
			echo json_encode($message);
				
			}
        }
        }
		
	/**
     * User match otp API
     * --------------------
     * @param: phone 
     * @param: otp
     * --------------------------
     * @method : POST
     * @link: api/Seeker/matchOtp
     */	
	 
	 public function matchOtp_post()
	 {
		 $this->form_validation->set_rules('phone', 'username', 'trim|required');
        $this->form_validation->set_rules('otp', 'otp', 'trim|required');
        if ($this->form_validation->run() == TRUE)
        {
			$output=$this->Seeker_model->matchOtp($this->input->post());
			if (!empty($output) AND $output != FALSE)
            {
				$this->Seeker_model->updateStatus($this->input->post());
                // Generate Token
                $token_data['id'] = $output->id;
                $token_data['username'] = $output->phone;
                $token_data['time'] = time();

                $user_token = $this->authorization_token->generateToken($token_data);

               echo json_encode(array('token'=>$user_token,'status' => true,'message'=>'otp matched','user_status'=>2));
			
		}else{
			     echo json_encode(array('status' => false,'message'=>'otp not matched'));
		}
	  }else{
	      	$message = array(
                'status' => false,
                'error' => $this->form_validation->error_array(),
                'message' => validation_errors()
            );
            	echo json_encode($message);
	  }
	 }
	 
	 /**
     * add User remaining info
     * --------------------
     * @param: user details 
     * --------------------------
     * @method : POST
     * @link: api/Seeker/UpdateUserDetails
     */	
	 
	 public function UpdateUserDetails_post()
	 {
	     
		 $is_valid_token = $this->authorization_token->validateToken();
        if (!empty($is_valid_token) AND $is_valid_token['status'] === TRUE)
        {
			$this->form_validation->set_rules('name', 'name', 'trim|required');
			$this->form_validation->set_rules('gender', 'gender', 'trim|required');
			$this->form_validation->set_rules('dob', 'dob', 'trim|required');
			$this->form_validation->set_rules('blood_group', 'blood_group', 'trim|required');
			$this->form_validation->set_rules('role', 'role', 'trim|required');
			if ($this->form_validation->run() == TRUE)
			{
			   
				$data=$this->input->post();
				
				$data['status']=3;
				if(isset($_FILES['profile']['name']))
				{
					$img_name = explode('.', $_FILES['profile']['name']);
					$extension = end($img_name);
					$pic_name=mt_rand().'.'.$extension;
					move_uploaded_file($_FILES['profile']['tmp_name'], 'assets/profile/' .$pic_name);
					$data['profile']=$pic_name;
				}else{
				    	$data['profile']='';
				}
			
			if($this->Seeker_model->UpdateUserDetails($data,$is_valid_token['data']->id))
			{
			    //echo $is_valid_token['data']->id;exit;
			    $row=$this->Seeker_model->getuserdetails($is_valid_token['data']->id);
			   // print_r($row);exit;
				echo json_encode(array('status' => true,'message'=>'update sucessfully','user_status'=>3,'user_data'=>$row[0]));
			}else{
			    echo json_encode(array('status' => false,'message'=>'internal server error'));
			}
				
				
			}else{
			    	$message = array(
                'status' => false,
                'error' => $this->form_validation->error_array(),
                'message' => validation_errors()
				
                 );
		    	echo json_encode($message);
			}
		}else{
			echo json_encode(array('message'=>'token not found', 'status'=>'false'));
			echo header("HTTP/1.1 401 Unauthorized");
		}
	 }
		

    /**
     * add user location
     * --------------------
     * @param:location details 
     * --------------------------
     * @method : POST
     * @link: api/Seeker/AddUserLocation
     */
	 
	 public function addLocation_post()
	 {
		  $is_valid_token = $this->authorization_token->validateToken();
        if (!empty($is_valid_token) AND $is_valid_token['status'] === TRUE)
        {
			$this->form_validation->set_rules('latitude', 'latitude', 'trim|required');
			$this->form_validation->set_rules('longitude', 'longitude', 'trim|required');
			$this->form_validation->set_rules('address', 'address', 'trim|required');
			$this->form_validation->set_rules('city', 'city', 'trim|required');
			$this->form_validation->set_rules('country', 'country', 'trim|required');
			$this->form_validation->set_rules('zip', 'zip', 'trim|required');
			if ($this->form_validation->run() == TRUE)
			{
				$data=$this->input->post();
			
			    $isexist=$this->Seeker_model->checkUserLocationExistance($is_valid_token['data']->id);
        			if(!empty($isexist))
        			{
        			    if($this->Seeker_model->UpdateLocation($is_valid_token['data']->id,$data));
        			    {
                            echo json_encode(array('status' => true,'message'=>'location updated sucessfully'));
        			    }
        			}else{
        			    	$data['user_id']=$is_valid_token['data']->id;
        				if($this->Seeker_model->addLocation($data))
        				{
        					echo json_encode(array('status' => true,'message'=>'location added sucessfully'));
        				}
        			}	
			}else{
			    	$message = array(
                'status' => false,
                'error' => $this->form_validation->error_array(),
                'message' => validation_errors()
                 );
		    	echo json_encode($message);
			}
		}else{
			echo json_encode(array('message'=>'token not found', 'status'=>'false'));
			echo header("HTTP/1.1 401 Unauthorized");
		}
	 }
	 
	 public function UpdateProfile_post()
	 {
	     $is_valid_token = $this->authorization_token->validateToken();
        if (!empty($is_valid_token) AND $is_valid_token['status'] === TRUE)
        {
            	if(isset($_FILES['profile']['name']))
				{
					$img_name = explode('.', $_FILES['profile']['name']);
					$extension = end($img_name);
					$pic_name=mt_rand().'.'.$extension;
					move_uploaded_file($_FILES['profile']['tmp_name'], 'assets/profile/' .$pic_name);
					$data['profile']=$pic_name;
					if($this->Seeker_model->UpdateUserDetails($data,$is_valid_token['data']->id))
        			{
        				echo json_encode(array('status' => true,'message'=>'profile update sucessfully'));
        			}
				}else{
				    	echo json_encode(array('status' => false,'message'=>'profile required'));
				}
        }else{
            echo json_encode(array('message'=>'token not found', 'status'=>'false'));
			echo header("HTTP/1.1 401 Unauthorized");
        }
	 }
	 
	 /** @param: donar information 
     * --------------------------
     * @method : POST
     * @link: api/Seeker/AddUserLocation
     */
	 
	 public function getDonarInfo_post()
	 {
		 $is_valid_token = $this->authorization_token->validateToken();
        if (!empty($is_valid_token) AND $is_valid_token['status'] === TRUE)
        {
			$this->form_validation->set_rules('donar_id', 'dobar_id', 'trim|required');
			if ($this->form_validation->run() == TRUE)
			{
			    
				if($output=$this->Seeker_model->getDonarInfo($this->input->post('donar_id')))
				{			
				   echo json_encode(array('status' => true,'message'=>$output));
				
				}else{
					 echo json_encode(array('status' => false,'message'=>'internal server error'));
				}
			}else{
				$message = array(
									'status' => false,
									'error' => $this->form_validation->error_array(),
									'message' => validation_errors()
								);
		    	echo json_encode($message);
			}	
		}else{		
			echo json_encode(array('message'=>'token not found', 'status'=>'false'));
			echo header("HTTP/1.1 401 Unauthorized");
		}
	 }
	 
	 public function getAllrequest_get()
	 {
		 $is_valid_token = $this->authorization_token->validateToken();
		if (!empty($is_valid_token) AND $is_valid_token['status'] === TRUE)
        {
			if($data=$this->Donor_model->getAllrequest($is_valid_token['data']->id))
			{
				$this->response(array('status' => true,'data'=>$data), REST_Controller::HTTP_OK);
			}else{
				$this->response(array('status' => false,'message'=>'internal server error'), REST_Controller::HTTP_NOT_FOUND);
			}

		}else{
			$this->response(array('status' => false,'message'=>'Do not show the popup'), REST_Controller::HTTP_OK);
		}
	 }
	 
	

}