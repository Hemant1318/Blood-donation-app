<?php defined('BASEPATH') OR exit('No direct script access allowed');

use Restserver\Libraries\REST_Controller;
if (isset($_SERVER['HTTP_ORIGIN'])) {
		header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
		header('Access-Control-Allow-Credentials: true');
		header('Access-Control-Max-Age: 86400'); 
	  }
		if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
		if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']))
				header("Access-Control-Allow-Methods: GET, POST, OPTIONS");         

			if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']))
				header("Access-Control-Allow-Headers: {$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");
				exit(0);
		}
require APPPATH . '/libraries/REST_Controller.php';
 
class Request extends \Restserver\Libraries\REST_Controller
{
    public function __construct() {
        parent::__construct();
        // Load User Model
        $this->load->model('Request_model');
    }
	 
	 /** @param: donar information 
     * --------------------------
     * @method : POST
     * @link: api/Seeker/AddUserLocation
     */
	 
	 public function sendRequest_post()
	 {
		 $is_valid_token = $this->authorization_token->validateToken();
        if (!empty($is_valid_token) AND $is_valid_token['status'] === TRUE)
        {
			$this->form_validation->set_rules('doner_id', 'doner_id', 'trim|required|numeric');
			$this->form_validation->set_rules('blood_for', 'blood_for', 'trim|required');
			$this->form_validation->set_rules('latitude', 'location', 'trim|required');
			$this->form_validation->set_rules('latitude', 'location', 'trim|required');
			if ($this->form_validation->run() == TRUE)
			{
				$_POST['requested_date']=Date('Y-m-d');
				$_POST['status']='requested';
				$_POST['seeker_id']=$is_valid_token['data']->id;
				if($output=$this->Request_model->sendRequest($_POST))
				{			
				   echo json_encode(array('status' => true,'message'=>'Request sent successfully'));
				
				}else{
					 echo json_encode(array('status' => false,'message'=>'internal server error'));
				}
			}else{
				$message = array(
									'status' => false,
									'error' => $this->form_validation->error_array(),
									'message' => validation_errors()
								);
		    	echo json_encode($message);
			}	
		}else{		
			echo json_encode(array('message'=>'token not found', 'status'=>'false'));
			echo header("HTTP/1.1 401 Unauthorized");
		}
	 }
	 
	 public function add_feedback_post()
	 {
		 $is_valid_token = $this->authorization_token->validateToken();
        if (!empty($is_valid_token) AND $is_valid_token['status'] === TRUE)
        {
			$this->form_validation->set_rules('how_to_know', 'how_to_know', 'trim|required');
			$this->form_validation->set_rules('about_service', 'about_service', 'trim|required');
			$this->form_validation->set_rules('rating', 'rating', 'trim|required');
			if ($this->form_validation->run() == TRUE)
			{	   
				$data=$this->input->post();
				if(isset($_FILES['pic']['name']))
				{
					$img_name = explode('.', $_FILES['pic']['name']);
					$extension = end($img_name);
					$pic_name=mt_rand().'.'.$extension;
					move_uploaded_file($_FILES['pic']['tmp_name'], 'assets/feedback/' .$pic_name);
					$data['pic']=$pic_name;
				}else{
				    	$data['pic']='';
				}
				
				$data['user_id']=$is_valid_token['data']->id;
			
			if($this->Request_model->add_feedback($data))
			{
				echo json_encode(array('status' => true,'message'=>'added sucessfully'));
			}else{
			    echo json_encode(array('status' => false,'message'=>'internal server error'));
			}
				
				
			}else{
			    	$message = array(
                'status' => false,
                'error' => $this->form_validation->error_array(),
                'message' => validation_errors()
				
                 );
		    	echo json_encode($message);
			}
		}else{
			echo json_encode(array('message'=>'token not found', 'status'=>'false'));
			echo header("HTTP/1.1 401 Unauthorized");
		}
	 }

}