<?php defined('BASEPATH') OR exit('No direct script access allowed');

use Restserver\Libraries\REST_Controller;
if (isset($_SERVER['HTTP_ORIGIN'])) {
		header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
		header('Access-Control-Allow-Credentials: true');
		header('Access-Control-Max-Age: 86400'); 
	  }
		if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
		if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']))
				header("Access-Control-Allow-Methods: GET, POST, OPTIONS");         

			if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']))
				header("Access-Control-Allow-Headers: {$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");
				exit(0);
		}
require APPPATH . '/libraries/REST_Controller.php';
 
class Admin extends \Restserver\Libraries\REST_Controller
{
    public function __construct() {
        parent::__construct();
        // Load User Model
        $this->load->model('Admin_model');
    }
	 
	 
	 public function checkLogin_post()
	 {
		$_POST= (array) json_decode(file_get_contents("php://input"), true);
        $_POST = $this->security->xss_clean($_POST);
        
        # Form Validation
        $this->form_validation->set_rules('username', 'email', 'trim|required');
        $this->form_validation->set_rules('password', 'password', 'trim|required');
        if ($this->form_validation->run() == FALSE)
        {
            // Form Validation Errors
            $message = array(
                'status' => false,
                'error' => $this->form_validation->error_array(),
                'message' => validation_errors()
            );

            $this->response($message, REST_Controller::HTTP_NOT_FOUND);
        }
        else
        {
            // Load Login Function
            $output = $this->Admin_model->adminLogin($_POST['username'], $_POST['password']);
			//print_r( $output);exit;
            if (!empty($output) AND $output != FALSE)
            {
                // Load Authorization Token Library
                $this->load->library('Authorization_Token');

                // Generate Token
                $token_data['id'] = $output->id;
                $token_data['username'] = $output->username;
				 $token_data['role'] ='admin';
                $token_data['time'] = time();

                $user_token = $this->authorization_token->generateToken($token_data);

               echo json_encode(array('token'=>$user_token));
            } else
            {
                // Login Error
               echo json_encode(0);
            }
        }
	 }
	 
	 public function getUsers_get()
	 {
		 echo json_encode($this->Admin_model->getUsers());
	 }

	 public function getFeedback_get()
	 {
		 echo json_encode($this->Admin_model->getFeedback());
	 }
	 
	 public function getDashboardInfo_get()
	 {
		$user=$this->Admin_model->getTotalUsers();
		$today_user=$this->Admin_model->getTodaysTotalUsers();
		$request=$this->Admin_model->getTotalrequest();
		$today_request=$this->Admin_model->getTotalTodayRequest();
		$done=$this->Admin_model->getTotalCompleted();
		$today_done=$this->Admin_model->getTodaysTotalCompleted();
		 echo json_encode(array('users'=>$user,'request'=>$request,'completed'=>$done,'today_user'=>$today_user,'today_request'=>$today_request,'today_done'=>$today_done));
	 } 
	 
	 public function getAllRequest_post()
	 {
		 $_POST= (array) json_decode(file_get_contents("php://input"), true);
		echo json_encode($this->Admin_model->getAllRequest($_POST['status']));
	 } 
	 
	 public function UserSearch_post()
	 {
		 $_POST= (array) json_decode(file_get_contents("php://input"), true);
		echo json_encode($this->Admin_model->UserSearch($_POST['from'],$_POST['to']));
	 } 
	 
	 public function RequestSearch_post()
	 {
		 $_POST= (array) json_decode(file_get_contents("php://input"), true);
		echo json_encode($this->Admin_model->RequestSearch($_POST['from'],$_POST['to']));
	 } 
	 
	 public function CompletedSearch_post()
	 {
		 $_POST= (array) json_decode(file_get_contents("php://input"), true);
		echo json_encode($this->Admin_model->CompletedSearch($_POST['from'],$_POST['to'],$_POST['status']));
	 }
	 
	 public function feedbackSearch_post()
	 {
		 $_POST= (array) json_decode(file_get_contents("php://input"), true);
		echo json_encode($this->Admin_model->feedbackSearch($_POST['from'],$_POST['to']));
	 }

}