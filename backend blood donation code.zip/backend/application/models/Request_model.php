<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Request_model extends CI_Model
{
    /**
     *  Send reuested
     */
	 
    public function sendRequest($data) {
       return $this->db->insert('blood_request', $data);
    }
	
	public function add_feedback($data) {
       return $this->db->insert('feedback', $data);
    }

}
