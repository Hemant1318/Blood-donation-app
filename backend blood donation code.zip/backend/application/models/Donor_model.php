<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Donor_model extends CI_Model
{
    public function getAllRequestById($id) {
       $this->db->select('*,blood_request.name as blood_for_other_name');
       $this->db->from('blood_request');
       $this->db->join('users','users.id=blood_request.doner_id');
       $this->db->where('doner_id',$id);
	    $this->db->where('blood_request.status','requested');
       return $this->db->get()->result_array();
    }
	
	/*public function actionOnRequest($data) {
       $this->db->select('*');
       $this->db->from('blood_request');
       $this->db->where('doner_id',$id);
       $this->db->where('status','requested');
       return $this->db->get()->result_array();
    }**/

	public function actionOnRequest($data) {
       $this->db->where('id',$data['blood_request_id']);
       return $this->db->update('blood_request',array('status'=>$data['action']));
    }
	
	public function isBloodDonated($id)
	{
		$this->db->select('id');
		$this->db->from('blood_request');
		$this->db->where('doner_id',$id);
		$this->db->where('status','waiting');
		$this->db->where('requested_date <=',Date('Y-m-d'));
		return $this->db->get()->result_array();
	}
	
	public function actionOnBloodDonation($user_id,$status,$id)
	{
		if($status=='accepted')
		{
			$NewDate=Date('Y-m-d', strtotime("+91 days"));
			$this->db->where('id',$user_id);
			 $this->db->update('users',array('not_eligible_till_date'=>$NewDate,'status'=>4));
			
			$this->db->where('id',$id);
			return $this->db->update('blood_request',array('status'=>'accepted'));
		}else if($status=='denied'){
			$this->db->where('id',$data['id']);
			return $this->db->update('blood_request',array('status'=>'denied'));
		}
		
	}

}
