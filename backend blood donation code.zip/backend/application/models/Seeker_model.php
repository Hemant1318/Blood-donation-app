<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Seeker_model extends CI_Model
{
    
    
    
     public function availabledonar($lagi,$lati,$Km)
    {
         
          /* $q1=$this->db->query("SELECT
  
  ACOS(
    SIN(RADIANS(`latitude`)) * SIN(RADIANS($lati)) + COS(RADIANS(`latitude`)) * COS(RADIANS($lati)) * COS(RADIANS(`longitude`) - RADIANS($lagi))
  ) * 6380 AS `distance`,user_location.*,users.*
 
FROM
      `user_location`
      inner join users on user_location.user_id=users.id
     
     
    WHERE
      ACOS(
        SIN(RADIANS(`latitude`)) * SIN(RADIANS($lati)) + COS(RADIANS(`latitude`)) * COS(RADIANS($lati)) * COS(RADIANS(`longitude`) - RADIANS($lagi))
      ) * 6380 < $Km and users.role='donar'
      
    GROUP by
  user_location.user_id
")->result_array();  **/

//$this->db->select('*');

//echo $q1 ;

         
         // return $q1;
     
       $this->db->select('*');
	    $this->db->from('users');
	    $this->db->where('role','Donar');
	    return $this->db->get()->result_array();
    }
    
    
    
    /**
     *  user Registration with mobile no
     */
	 
    public function addUser($data) {
       return $this->db->insert('users', $data);
    }

    /**
     * check user opt
     * ----------------------------------
     * @param: opt and phone
     */
    public function matchOtp($data)
    {
        $this->db->where($data);
        $q = $this->db->get('users');
        if( $q->num_rows() ) 
        {
                return $q->row();
         }
            return FALSE;
    }
	
	/**
     * Update user details
     * ----------------------------------
     * @param: user data and id
     */
	public function UpdateUserDetails($data,$id)
	{
		$this->db->where('id',$id);	
		return $this->db->update('users',$data);	
	}
	
		public function updateOtp($otp,$mob)
	{
		$this->db->where('phone',$mob);	
		return $this->db->update('users',array('otp'=>$otp));	
	}
	
	
	
	/**
     * Update status
     * ----------------------------------
     * @param: mobile and otp
     */
	public function updateStatus($data)
	{
		$this->db->where('otp',$data['otp']);	
		$this->db->where('phone',$data['phone']);	
		return $this->db->update('users',array('status'=>2));	
	}
	
	public function checkUserExististance($mob)
	{
	    $this->db->select('*,users.id as user_id');
	    $this->db->from('users');
	    $this->db->join('user_location','users.id=user_location.user_id','left');
	    $this->db->where('phone',$mob);
	    return $this->db->get()->result_array();
	}
	
	public function getuserdetails($id)
	{
	    $this->db->select('*');
	    $this->db->from('users');
	    $this->db->join('user_location','users.id=user_location.user_id','left');
	    $this->db->where('users.id',$id);
	    return $this->db->get()->result_array();
	}
	
	/**
     * Update user details
     * ----------------------------------
     * @param: user data and id
     */
	public function addLocation($data)
	{
		return $this->db->insert('user_location', $data);
	}
	
	/**
     * check User Location Existance
     * ----------------------------------
     * @param: user data and id
     */
	public function checkUserLocationExistance($id)
	{
	    $this->db->select('id');
	    $this->db->from('user_location');
	    $this->db->where('user_id',$id);
	    return $this->db->get()->result_array();
	}
	
	/**
     * Update Location
     * ----------------------------------
     * @param: location
     */
	public function UpdateLocation($id,$data)
	{
		$this->db->where('user_id',$id);	
		return $this->db->update('user_location',$data);	
	}
	
	/**
     * get donar info
     * ----------------------------------
     * @param: donar_id
     */
	public function getDonarInfo($id)
	{
		$this->db->select('*');
	    $this->db->from('users');
	     $this->db->join('user_location','users.id=user_location.user_id','left');
	    $this->db->where('users.id',$id);
	    return $this->db->get()->result_array();
	}
	
	/**
     * get all request
     * ----------------------------------
     * @param: id
     */
	public function getAllrequest($id)
	{
		$this->db->select('*');
	    $this->db->from('users');
	     $this->db->join('blood_request','users.id=blood_request.seeker_id','left');
	    $this->db->where('users.id',$id);
	    return $this->db->get()->result_array();
	}
	
	
}
