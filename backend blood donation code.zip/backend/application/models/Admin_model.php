<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Admin_model extends CI_Model
{
    public function adminLogin($username, $password)
    {
		
        $this->db->where('username',$username);
        $q = $this->db->get('admin');

        if( $q->num_rows() ) 
        {
            $user_pass = $q->row('password');
            if(($password) === $user_pass) {
                return $q->row();
            }
            return FALSE;
        }else{
            return FALSE;
        }
    }
	
	public function getUsers()
	{
		$this->db->select('*');
	    $this->db->from('users');
	     $this->db->join('user_location','users.id=user_location.user_id','left');
		 $this->db->where('status','active');
		return $this->db->get()->result();
	}

	public function getFeedback()
	{
		$this->db->select('*');
	    $this->db->from('feedback');
	     $this->db->join('users','users.id=feedback.user_id');
		return $this->db->get()->result();
	}
	
	public function feedbackSearch($mindate,$maxdate)
	{
		$this->db->select('*');
	    $this->db->from('feedback');
	     $this->db->join('users','users.id=feedback.user_id');
		 $this->db->where('feedback.creation_date>=',$mindate);
		 $this->db->where('feedback.creation_date<=',$maxdate);
		return $this->db->get()->result();
	}

	public function UserSearch($mindate,$maxdate)
	{
		$this->db->select('*');
	    $this->db->from('users');
	     $this->db->join('user_location','users.id=user_location.user_id','left');
		 $this->db->where('creation_date>=',$mindate);
		 $this->db->where('creation_date<=',$maxdate);
		return $this->db->get()->result();
	}
	
	public function getTotalUsers()
	{
		$this->db->select('id');
	    $this->db->from('users');
		return $this->db->get()->num_rows();
	}
	
	public function getTodaysTotalUsers()
	{
		$this->db->select('id');
	    $this->db->from('users');
	    $this->db->where('creation_date',date('Y-m-d'));
		return $this->db->get()->num_rows();
	}
	
	public function getTotalrequest()
	{
		$this->db->select('id');
	    $this->db->from('blood_request');
	    $this->db->where('status','requested');
		return $this->db->get()->num_rows();
	}

	public function getTotalTodayRequest()
	{
		$this->db->select('id');
	    $this->db->from('blood_request');
	    $this->db->where('status','requested');
		 $this->db->where('requested_date',date('Y-m-d'));
		return $this->db->get()->num_rows();
	}
	
	public function getTotalCompleted()
	{
		$this->db->select('id');
	    $this->db->from('blood_request');
	    $this->db->where('status','completed');
		return $this->db->get()->num_rows();
	}
	public function getTodaysTotalCompleted()
	{
		$this->db->select('id');
	    $this->db->from('blood_request');
	    $this->db->where('status','completed');
		$this->db->where('appointment',date('Y-m-d'));
		return $this->db->get()->num_rows();
	}

	public function getAllRequest($staus)
	{
		
		//$this->db->select('users.name as seeker_name,blood_group,requested_date');
	   // $this->db->from('blood_request');
	    ////$this->db->join('users','users.id=blood_request.seeker_id');
	    //$this->db->where('blood_request.status',$staus);
		//return $this->db->get()->result();
		$sql="select b.*, u1.name as doner, u1.phone as doner_phone, u1.blood_group as doner_blood_group,u1.role as d_role, u2.name as seeker, u2.phone as seeker_phone,u2.role as s_role, u2.blood_group as seeker_blood_group from blood_request b join users u1 on u1.id = b.doner_id join users u2 on u2.id = b.seeker_id where b.status='".$staus."'";
		//echo $sql;exit;
		return $this->db->query($sql)->result_array();
	}

	public function RequestSearch($mindate,$maxdate)
	{
		//$this->db->select('users.name as seeker_name,blood_group,requested_date');
	   // $this->db->from('blood_request');
	    //$this->db->join('users','users.id=blood_request.seeker_id');
		//$this->db->where('requested_date>=',$mindate);
		//$this->db->where('requested_date<=',$maxdate);
	    //$this->db->where('blood_request.status','requested');
		//return $this->db->get()->result();
		
		$sql="select b.*, u1.name as doner, u1.phone as doner_phone, u1.blood_group as doner_blood_group,u1.role as d_role, u2.name as seeker, u2.phone as seeker_phone,u2.role as s_role, u2.blood_group as seeker_blood_group from blood_request b join users u1 on u1.id = b.doner_id join users u2 on u2.id = b.seeker_id where b.status='requested' and requested_date >='".$mindate."' and requested_date<='".$maxdate."'";
		return $this->db->query($sql)->result_array();
		 $this->db->last_query();
		
		
	}

	public function CompletedSearch($mindate,$maxdate,$status)
	{
		//$this->db->select('users.name as seeker_name,blood_group,requested_date');
	   // $this->db->from('blood_request');
	   // $this->db->join('users','users.id=blood_request.seeker_id');
		//$this->db->where('requested_date>=',$mindate);
		// $this->db->where('requested_date<=',$maxdate);
	    //$this->db->where('blood_request.status',$status);
		//return $this->db->get()->result();
		
		$sql="select b.*, u1.name as doner, u1.phone as doner_phone, u1.blood_group as doner_blood_group,u1.role as d_role, u2.name as seeker, u2.phone as seeker_phone,u2.role as s_role, u2.blood_group as seeker_blood_group from blood_request b join users u1 on u1.id = b.doner_id join users u2 on u2.id = b.seeker_id where b.status='requested' and requested_date >='".$mindate."' and requested_date<='".$maxdate."'";
		return $this->db->query($sql)->result_array();
	}

}
